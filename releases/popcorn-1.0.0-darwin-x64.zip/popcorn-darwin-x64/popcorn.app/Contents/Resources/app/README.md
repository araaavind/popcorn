# Popcorn video player

> A cross-platform watch-party video player for synchronized and seamless binging with your friends!

### Main Features
1. **Playback Synchronization** - The video playback will be synced with your friends in party for seamless binging experience.
2. **Chat in watch party** - One-on-One and Group party sessions to chat on-screen with your friends while watching the movie.
3. **Picture-in-Picture mode** - Video overlays on the screen while you do your important tasks in the background.